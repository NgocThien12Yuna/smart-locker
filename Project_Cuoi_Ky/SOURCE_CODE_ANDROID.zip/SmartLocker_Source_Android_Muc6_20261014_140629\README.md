# SmartLocker - Source Code Android (Muc 6)

## Gioi thieu
Bo ma nguon ung dung Android SmartLocker, phat trien bang
React Native, TypeScript va Kotlin Native.

Bo nop duoc trich xuat tu project SmartLockerApp de phuc vu
Muc 6 - Source code Android (duoi 20 MB).

## Chuc nang
- Shipper: dang nhap, chup van don, OCR so dien thoai,
  tao don giao hang.
- Cu dan: nhan thong bao Firebase, xem OTP, mo tu,
  xac nhan tat relay sau khi nhan hang.
- Admin: quan ly trang thai tu, lich su va mo khan cap.
- OCR: TypeScript + Kotlin Native + ONNX Runtime.
- Phan cung: giao tiep Backend de xu ly OPEN/CLOSE
  va kiem tra trang thai lenh ESP32.

He thong co 4 ngan tu: A01, A02, B01, B05.

## Cau truc
- App.tsx, index.js: diem khoi chay.
- src/screens: cac man hinh.
- src/context: quan ly trang thai.
- src/navigation: dieu huong.
- src/services: authentication va Firebase.
- src/config: Backend API.
- src/ai: logic xu ly OCR.
- android/app/src/main/java: Kotlin va Native OCR.
- android/app/src/main/res: tai nguyen Android.
- android/app/src/main/assets/smartlocker:
  metadata va tu dien OCR.
- android: Gradle va Android configuration.
- docs/README_Project_Goc.md:
  README day du cua repository goc.

## Pham vi bo nop
Day la bo MA NGUON ANDROID, khong kem:
- node_modules, Gradle cache, file build, APK/AAB.
- Model ONNX/TFLite dung luong lon.
- Backend, SQLite, firmware ESP32.
- Mat khau, khoa bi mat va file cau hinh ca nhan.

Bo nop dung de xem xet va danh gia source code.
De chay lai ung dung can cai dependencies va bo sung
cau hinh Firebase, model AI va Backend tuong ung.

## Ghi chu
Ma nguon duoc sao chep nguyen ban tu project tai
thoi diem dong goi. Khong sua logic ung dung.

SmartLocker - Android Application Source Code.