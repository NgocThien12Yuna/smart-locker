# Export Recognizer TopK-F32 cho Android

Sau notebook huấn luyện 14 cell, **Cell 13** tạo raw ONNX `model2_recognizer.onnx` tại `/kaggle/working/smartlocker_onnx/`. Raw recognizer có một output xác suất `[N,T,C]` từ Softmax. Android Native Speed V3 không đọc tensor lớn này mà dùng bản tối ưu TopK-F32.

Chạy trên Kaggle (copy file `export_recognizer_topk_f32.py` vào `/kaggle/working/`):

```bash
python -m pip install onnx onnxruntime numpy
python /kaggle/working/export_recognizer_topk_f32.py \
  --input /kaggle/working/smartlocker_onnx/model2_recognizer.onnx \
  --output /kaggle/working/smartlocker_topk_f32/model2_recognizer.onnx
```

Script kiểm tra ONNX, thêm `TopK(k=2)` sau Softmax, đổi chỉ số INT64 sang FLOAT32 để Android ONNX Runtime đọc qua `floatBuffer`, rồi so sánh đầu ra với mô hình gốc bằng ONNX Runtime. Các output đúng tên:

- `smartlocker_top2_values` — `FLOAT32[N,T,2]`.
- `smartlocker_top2_indices_f32` — `FLOAT32[N,T,2]`.

Khi triển khai, đặt kết quả vào `android/app/src/main/assets/smartlocker/model2_recognizer.onnx` và dictionary tương ứng trong assets. Detector vẫn dùng `model1_detector.onnx` từ Cell 13; không chuyển Detector sang TopK.

**Phân biệt tái tạo và đối chiếu:** script tái tạo **kiến trúc và giao diện đầu ra TopK-F32**, không đảm bảo SHA256 của trọng số sẽ giống bản APK hiện hành nếu lần fine-tune/phiên bản export khác. SHA256 của trọng số stable được ghi trong `05_DATASET_AND_MODELS/PHIEN_BAN_MODEL.md`.
