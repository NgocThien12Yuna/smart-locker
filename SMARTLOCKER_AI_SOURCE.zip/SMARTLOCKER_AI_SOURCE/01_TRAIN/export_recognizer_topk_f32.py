#!/usr/bin/env python3
"""Create the Android TopK-F32 PP-OCRv6 recognizer from Cell 13 raw ONNX.

Converts the raw Paddle2ONNX recognizer output (post-Softmax [N,T,C]) to:
 - smartlocker_top2_values [N,T,2] float32
 - smartlocker_top2_indices_f32 [N,T,2] float32

The output contract matches SmartLockerOcrNativeModule.kt (Native Speed V3).
Weights of the original recognizer are retained; no training is performed.
"""

import argparse
from pathlib import Path

VALUES_NAME = "smartlocker_top2_values"
INDICES_NAME = "smartlocker_top2_indices_f32"
INDICES_I64_NAME = "smartlocker_top2_indices_i64"
K_NAME = "smartlocker_topk_k"


def dim_value(dim, fallback):
    if dim.HasField("dim_value") and dim.dim_value > 0:
        return int(dim.dim_value)
    if dim.HasField("dim_param") and dim.dim_param:
        return dim.dim_param
    return fallback


def convert(input_file: Path, output_file: Path, runtime_check=True):
    try:
        import onnx
        from onnx import helper, TensorProto
    except ImportError as exc:
        raise SystemExit("Cần cài: python -m pip install onnx numpy onnxruntime") from exc

    if not input_file.exists():
        raise SystemExit(f"Không thấy ONNX gốc từ Cell 13: {input_file}")

    model = onnx.load(str(input_file))
    onnx.checker.check_model(model)
    outputs = list(model.graph.output)

    if len(outputs) == 2 and {o.name for o in outputs} == {VALUES_NAME, INDICES_NAME}:
        raise SystemExit("Input đã là TopK-F32; không export TopK lặp lần hai.")

    if len(outputs) != 1:
        raise SystemExit(f"Cần raw recognizer có 1 output [N,T,C]; đang có {[o.name for o in outputs]}")

    raw = outputs[0]
    shape = raw.type.tensor_type.shape.dim
    if raw.type.tensor_type.elem_type != TensorProto.FLOAT or len(shape) != 3:
        raise SystemExit("Output gốc cần là tensor FLOAT [batch, timestep, class]")

    class_dim = shape[2]
    if class_dim.HasField("dim_value") and class_dim.dim_value and class_dim.dim_value < 2:
        raise SystemExit("Recognizer phải có ít nhất 2 lớp ký tự.")

    # Paddle2ONNX raw output is the post-Softmax tensor; TopK must work on
    # probabilities (do not append an extra Softmax).
    producer = {out: node for node in model.graph.node for out in node.output}
    source_node = producer.get(raw.name)
    if source_node is None or source_node.op_type != "Softmax":
        raise SystemExit(
            "Raw ONNX output không đến trực tiếp từ Softmax. "
            f"Producer={source_node.op_type if source_node else None}. "
            "Cần kiểm tra graph trước khi biến đổi để tránh sai confidence."
        )

    if not any(x.domain in ("", "ai.onnx") and x.version >= 11 for x in model.opset_import):
        raise SystemExit("TopK với K tensor yêu cầu ai.onnx opset >= 11")

    existing = set(producer)
    existing.update(x.name for x in model.graph.initializer)
    for name in [VALUES_NAME, INDICES_NAME, INDICES_I64_NAME, K_NAME]:
        if name in existing:
            raise SystemExit(f"Tên tensor đã tồn tại: {name}")

    k = helper.make_tensor(K_NAME, TensorProto.INT64, [1], [2])
    model.graph.initializer.append(k)
    model.graph.node.extend([
        helper.make_node(
            "TopK", [raw.name, K_NAME], [VALUES_NAME, INDICES_I64_NAME],
            axis=-1, largest=1, sorted=1, name="SmartLockerTopK2",
        ),
        helper.make_node(
            "Cast", [INDICES_I64_NAME], [INDICES_NAME],
            to=TensorProto.FLOAT, name="SmartLockerTopKIndicesToFloat",
        ),
    ])

    n = dim_value(shape[0], "batch")
    t = dim_value(shape[1], "timesteps")
    del model.graph.output[:]
    model.graph.output.extend([
        helper.make_tensor_value_info(VALUES_NAME, TensorProto.FLOAT, [n, t, 2]),
        helper.make_tensor_value_info(INDICES_NAME, TensorProto.FLOAT, [n, t, 2]),
    ])
    onnx.checker.check_model(model)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    onnx.save(model, str(output_file))
    onnx.checker.check_model(onnx.load(str(output_file)))

    if runtime_check:
        try:
            import numpy as np
            import onnxruntime as ort
        except ImportError as exc:
            raise SystemExit("Cài onnxruntime + numpy để chạy test đối chiếu đầu ra") from exc
        orig = ort.InferenceSession(str(input_file), providers=["CPUExecutionProvider"])
        topk = ort.InferenceSession(str(output_file), providers=["CPUExecutionProvider"])
        if set(x.name for x in topk.get_outputs()) != {VALUES_NAME, INDICES_NAME}:
            raise RuntimeError("Không đúng hai tên output dành cho Android")
        inputs = orig.get_inputs()
        if len(inputs) != 1:
            raise RuntimeError("Recognizer kỳ vọng một input ảnh [N,3,48,320]")
        shp = [d if isinstance(d, int) and d > 0 else (48 if i == 2 else 320 if i == 3 else 1)
               for i, d in enumerate(inputs[0].shape)]
        x = np.random.default_rng(7).random(shp, dtype=np.float32)
        full = orig.run(None, {inputs[0].name: x})[0]
        v, ix = topk.run([VALUES_NAME, INDICES_NAME], {inputs[0].name: x})
        if v.shape != ix.shape or v.shape[-1] != 2:
            raise RuntimeError("Output TopK không phải [N,T,2]")
        ix = np.rint(ix).astype(np.int64)
        recomputed = np.take_along_axis(full, ix, axis=-1)
        expected = np.sort(full, axis=-1)[..., -2:][..., ::-1]
        if not (np.allclose(v, recomputed, atol=1e-5) and
                np.allclose(v, expected, atol=1e-5)):
            raise RuntimeError("TopK không khớp raw recognizer; KHÔNG deploy")
        print("PASS: ONNX checker + ORT parity + TopK-F32 output contract")
    else:
        print("ONNX checker PASS. CẢNH BÁO: chưa thực hiện ORT output parity")

    print(f"Xuất thành công: {output_file}")
    print("Android asset: android/app/src/main/assets/smartlocker/model2_recognizer.onnx")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", type=Path, required=True, help="Raw model2_recognizer.onnx từ Cell 13")
    p.add_argument("--output", type=Path, required=True, help="TopK-F32 model2_recognizer.onnx")
    p.add_argument("--skip-runtime-check", action="store_true", help="Không khuyên dùng khi nộp/triển khai")
    args = p.parse_args()
    if args.input.resolve() == args.output.resolve():
        p.error("Đường dẫn --input và --output phải khác nhau, tránh ghi đè bản gốc")
    convert(args.input, args.output, runtime_check=not args.skip_runtime_check)


if __name__ == "__main__":
    main()
