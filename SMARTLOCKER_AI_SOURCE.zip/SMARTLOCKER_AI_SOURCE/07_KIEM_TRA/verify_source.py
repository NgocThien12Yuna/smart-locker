#!/usr/bin/env python3
"""Kiểm tra tính đầy đủ của gói mã nguồn AI nộp thầy (không cần pip)."""
from pathlib import Path
import hashlib
import json
import csv
import ast
import sys

ROOT = Path(__file__).resolve().parents[1]
expected = {
    "01_TRAIN/SmartLocker_PP-OCRv6_MC-OCR_FULL_14_CELLS_FIXED_V2.ipynb",
    "01_TRAIN/export_recognizer_topk_f32.py",
    "01_TRAIN/QUY_TRINH_EXPORT_TOPK.md",
    "02_EVAL/SMARTLOCKER_TEST_FULL_8_CELLS_V4_HYBRID.ipynb",
    "02_EVAL/ground_truth_FIXED.csv",
    "03_ANDROID_APP/src/ai/smartlockerOcr.ts",
    "03_ANDROID_APP/src/screens/ShipperScreen.tsx",
    "03_ANDROID_APP/android/app/src/main/java/com/smartlockerapp/ai/SmartLockerOcrNativeModule.kt",
    "03_ANDROID_APP/android/app/src/main/java/com/smartlockerapp/ai/SmartLockerOcrNativePackage.kt",
    "03_ANDROID_APP/android/app/src/main/java/com/smartlockerapp/MainApplication.kt",
    "03_ANDROID_APP/android/app/build.gradle",
    "03_ANDROID_APP/android/app/src/main/AndroidManifest.xml",
    "03_ANDROID_APP/package.json",
    "04_MODEL_DICTIONARY/ppocr_keys.txt",
    "05_DATASET_AND_MODELS/DATASET_MC_OCR.md",
    "05_DATASET_AND_MODELS/PHIEN_BAN_MODEL.md",
    "06_HUONG_DAN/01_GIOI_THIEU_VA_LUONG_AI.md",
    "06_HUONG_DAN/02_GIAI_THICH_TUNG_FILE.md",
    "06_HUONG_DAN/03_CACH_CHAY_KAGGLE_VA_ANDROID.md",
    "README.md",
}
for rel in sorted(expected):
    path = ROOT / rel
    assert path.is_file() and path.stat().st_size, f"Thiếu file: {rel}"

train = json.loads((ROOT / "01_TRAIN/SmartLocker_PP-OCRv6_MC-OCR_FULL_14_CELLS_FIXED_V2.ipynb").read_text(encoding="utf8"))
eval_nb = json.loads((ROOT / "02_EVAL/SMARTLOCKER_TEST_FULL_8_CELLS_V4_HYBRID.ipynb").read_text(encoding="utf8"))
assert len(train["cells"]) == 14, "Train notebook không phải 14 cell"
assert len(eval_nb["cells"]) == 8, "Eval notebook không phải 8 cell"
assert all(c.get("source") for c in train["cells"]), "Có train cell trống"

export_file = ROOT / "01_TRAIN/export_recognizer_topk_f32.py"
ast.parse(export_file.read_text(encoding="utf8"), filename=str(export_file))

with (ROOT / "02_EVAL/ground_truth_FIXED.csv").open(newline="", encoding="utf-8-sig") as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 36, f"Ground truth cần 36 ảnh, nhận {len(rows)}"

keys = ROOT / "04_MODEL_DICTIONARY/ppocr_keys.txt"
assert hashlib.sha256(keys.read_bytes()).hexdigest() == "b5f2bfe2bdd9448429e3e82b51c789775d9b42f2403d082b00662eb77e401c5d"
assert len(keys.read_text(encoding="utf8").splitlines()) == 18708

kt = (ROOT / "03_ANDROID_APP/android/app/src/main/java/com/smartlockerapp/ai/SmartLockerOcrNativeModule.kt").read_text(encoding="utf8")
topk = export_file.read_text(encoding="utf8")
for name in ["smartlocker_top2_values", "smartlocker_top2_indices_f32"]:
    assert name in kt and name in topk, f"Mismatch Kotlin/TopK: {name}"
assert "SmartLockerTopK2" in topk and "SmartLockerTopKIndicesToFloat" in topk
assert "DESKEW_MAX_DEG" in kt and "REC_BATCH_SIZE = 16" in kt
assert "V4" in (ROOT / "03_ANDROID_APP/src/ai/smartlockerOcr.ts").read_text(encoding="utf8")
assert "https://www.kaggle.com/datasets/" in (ROOT / "05_DATASET_AND_MODELS/DATASET_MC_OCR.md").read_text(encoding="utf8")

# Checksums of all files recorded in SHA256_SOURCE.txt.
manifest = ROOT / "07_KIEM_TRA/SHA256_SOURCE.txt"
if manifest.exists():
    for line in manifest.read_text(encoding="utf8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        file = ROOT / rel
        assert file.is_file(), f"Checksum manifest tham chiếu file thiếu: {rel}"
        assert hashlib.sha256(file.read_bytes()).hexdigest() == digest, f"Sai SHA256: {rel}"

print("PASS: Train 14 cell, Eval 8 cell, 36 ground truth, dictionary 18.708 ký tự.")
print("PASS: Script export TopK-F32 có cú pháp đúng, hai output khớp Kotlin Native Speed V3.")
print("PASS: Source AI, hướng dẫn, dataset URL và SHA256 manifest đầy đủ.")
print("Chú ý: xác thực inference/training end-to-end phải chạy trên Kaggle/Android với weights và dữ liệu thực.")
