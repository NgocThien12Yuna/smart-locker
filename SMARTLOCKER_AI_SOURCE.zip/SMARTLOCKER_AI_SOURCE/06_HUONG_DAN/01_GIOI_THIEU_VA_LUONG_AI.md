# 01 — GIỚI THIỆU & LUỒNG AI

## Bài toán

Từ ảnh bill vận chuyển, SmartLocker cần lấy **số điện thoại người nhận**. Không được chọn nhầm SĐT người gửi, chuỗi mã vận đơn hoặc mã đơn hàng.

## Huấn luyện (Notebook 14 cell)

`MC-OCR -> polygon annotations -> text-line crops -> fine-tune Recognizer -> phone augmentation -> đánh giá -> Paddle inference -> ONNX`

Detector V6 sử dụng trọng số pretrained; Recognizer V6 trải qua hai stage fine-tune.

## Suy luận trên ứng dụng Android

```text
React Native camera chụp bill
    |
    v
Android Kotlin native module
    |
    +--> Decode / resize / auto-deskew
    |
    +--> PP-OCRv6 Detector ONNX: tìm text boxes
    |
    +--> PP-OCRv6 Recognizer TopK-F32 ONNX: nhận dạng ký tự
    |
    +--> Chuyển lines (text, confidence, toạ độ) sang TypeScript
    |
    v
Receiver Selector V4
    |
    +--> Trích xuất ứng viên SĐT Việt Nam
    +--> Nhận dạng ngữ cảnh Người nhận / Người gửi
    +--> Candidate scoring, confidence và margin
    +--> Ưu tiên R0; khi chưa đủ chắc, kiểm tra 90/270/180 độ
    |
    v
SĐT người nhận (hoặc kết quả chưa chắc chắn cho phép sửa tay)
```

## Hai lớp đánh giá

1. Đánh giá Recognizer trên tập kiểm tra OCR của MC-OCR (như trong notebook train).
2. Đánh giá đầu-cuối về đúng số điện thoại người nhận trên bộ robustness/unseen (notebook 8 cell). Ground truth được dùng để chấm **sau khi dự đoán**, không được dùng khi chọn điện thoại.

Kết quả kiểm thử phải được tính từ lần chạy thực tế của notebook; source đánh giá cung cấp công thức, không gán sẵn một tỷ lệ dự đoán.
