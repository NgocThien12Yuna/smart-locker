# 02 — GIẢI THÍCH TỪNG FILE SOURCE AI

## 01_TRAIN

**`SmartLocker_PP-OCRv6_MC-OCR_FULL_14_CELLS_FIXED_V2.ipynb`**  
Notebook Kaggle 14 cell. Kiểm tra GPU và cài PaddleOCR, tìm bộ dữ liệu MC-OCR public, tải pretrained, tạo crop dòng chữ, fine-tune Recognizer theo Stage A/Stage B, đánh giá, export ONNX và đóng gói output. Đây là **mã huấn luyện thực tế** của dự án.

**`export_recognizer_topk_f32.py`**  
Mã hậu xử lý export ONNX từ Cell 13 thành model TopK-F32 có output `smartlocker_top2_values` và `smartlocker_top2_indices_f32`; có kiểm tra parity bằng ONNX Runtime.

**`QUY_TRINH_EXPORT_TOPK.md`**  
Lệnh chạy và giải thích giao diện đầu ra khi triển khai.

## 02_EVAL

**`SMARTLOCKER_TEST_FULL_8_CELLS_V4_HYBRID.ipynb`**  
Notebook 8 cell đánh giá đầu-cuối, đưa ảnh qua OCR nhiều góc, tính điểm lựa chọn người nhận theo ngữ cảnh và đối chiếu nhãn. Có code tạo CSV dự đoán và tóm tắt thống kê.

**`ground_truth_FIXED.csv`**  
Nhãn tham chiếu của 36 ảnh robustness, gồm file ảnh, biến thể và SĐT người nhận mong đợi.

## 03_ANDROID_APP

**`src/ai/smartlockerOcr.ts`**  
Mã TypeScript xử lý OCR lines sau native inference: xác định ứng viên số điện thoại, phân biệt vùng/ngữ cảnh người gửi/người nhận, Candidate Scoring V4, đưa ra độ tin cậy và logic fallback theo góc xoay.

**`android/app/src/main/java/com/smartlockerapp/ai/SmartLockerOcrNativeModule.kt`**  
Mô-đun Kotlin: nạp model ONNX và dictionary từ assets, tiền xử lý ảnh, auto-deskew, chạy detector, crop theo text boxes, recognizer batch và CTC TopK decoding, trả text/tọa độ/confidence/profile.

**`android/app/src/main/java/com/smartlockerapp/ai/SmartLockerOcrNativePackage.kt`**  
Đăng ký native module để React Native có thể gọi.

**`android/app/src/main/java/com/smartlockerapp/MainApplication.kt`**  
Đưa Native Package vào danh sách package của ứng dụng.

**`src/screens/ShipperScreen.tsx`**  
Giao diện chụp ảnh bill và kết nối kết quả AI với quy trình gửi hàng.

**`android/app/build.gradle`**  
Cấu hình build, bao gồm phụ thuộc ONNX Runtime Android.

**`android/app/src/main/AndroidManifest.xml`**  
Cấu hình quyền/khai báo của ứng dụng Android.

**`package.json`**  
Danh sách phiên bản thư viện React Native của project đang dùng.

## 04_MODEL_DICTIONARY

**`ppocr_keys.txt`**  
Danh sách ký tự cho recognizer để chuyển class ID thành chữ, số và dấu. Nội dung giữ nguyên theo gói model stable.

## 05_DATASET_AND_MODELS

**`DATASET_MC_OCR.md`**  
Đường dẫn bộ dữ liệu công khai và các đầu vào được tìm trong notebook.

**`PHIEN_BAN_MODEL.md`**  
Tên đường dẫn asset, dung lượng và SHA-256 của model ONNX stable.

## 07_KIEM_TRA

**`verify_source.py`**  
Kiểm tra số lượng cell và sự hiện diện của code huấn luyện, đánh giá, các file Kotlin/TypeScript và từ điển bằng Python chuẩn; không cần cài thêm thư viện.
