# HƯỚNG DẪN CHẠY MÃ AI SMARTLOCKER

## 1. Huấn luyện, tạo raw ONNX (Kaggle)

- Import notebook `01_TRAIN/SmartLocker_PP-OCRv6_MC-OCR_FULL_14_CELLS_FIXED_V2.ipynb` và bật GPU. 
- Add Input dataset MC-OCR từ link ở `05_DATASET_AND_MODELS/DATASET_MC_OCR.md`.
- Chạy 14 cell theo thứ tự. Cell 7 xuất Detector pretrained; Cell 8–10 huấn luyện/fine-tune Recognizer; Cell 13 xuất hai raw ONNX vào `/kaggle/working/smartlocker_onnx/`.
- Cell 14 đóng gói raw ONNX và các tài liệu chứng cứ train; đó **chưa** phải biến thể Recognizer TopK-F32 mà app Kotlin đang dùng.

## 2. Đóng gói Recognizer TopK-F32 (Kaggle)

Trong cùng môi trường sau Cell 13, copy `01_TRAIN/export_recognizer_topk_f32.py` vào `/kaggle/working/`, cài `onnx`, `onnxruntime`, `numpy`, và chạy:

```bash
python /kaggle/working/export_recognizer_topk_f32.py --input /kaggle/working/smartlocker_onnx/model2_recognizer.onnx --output /kaggle/working/smartlocker_topk_f32/model2_recognizer.onnx
```

Kết quả phải có thông báo `PASS: ONNX checker + ORT parity + TopK-F32 output contract` trước khi dùng. Detector vẫn là `model1_detector.onnx` ở `smartlocker_onnx/`.

## 3. Kiểm thử Receiver Selector V4 (Kaggle)

Import notebook `02_EVAL/SMARTLOCKER_TEST_FULL_8_CELLS_V4_HYBRID.ipynb`; Add Input bao gồm các model inference, ảnh robustness và ảnh unseen. Tham chiếu định dạng nhãn ở `02_EVAL/ground_truth_FIXED.csv`. Notebook thực hiện OCR 4 hướng, lọc phone, Candidate Scoring V4, tổng hợp và ghi bảng đánh giá. Ground truth chỉ dùng sau khi đã dự đoán để chấm.

## 4. Tích hợp vào SmartLocker React Native / Android

Đặt các file source dưới `03_ANDROID_APP` theo đúng đường dẫn trong project của nhóm. Các model/dictionary làm asset:

```text
android/app/src/main/assets/smartlocker/
    model1_detector.onnx     # Detector từ Cell 13
    model2_recognizer.onnx   # bản TopK-F32 ở bước 2
    ppocr_keys.txt          # đi kèm recognizer
```

Cấu hình native package/ONNX Runtime nằm trong `03_ANDROID_APP`. Build lại ứng dụng sau khi thay model/Java/Kotlin. Vì đây là **source AI trích từ project**, không phải toàn bộ project React Native độc lập, việc chạy màn hình `ShipperScreen.tsx` cần project ứng dụng đầy đủ với các dependency/backend tương ứng.

## 5. Kiểm tra gói nộp

```bash
python 07_KIEM_TRA/verify_source.py
```
