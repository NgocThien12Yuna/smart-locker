# DATASET PUBLIC MC-OCR

**Tên:** Vietnamese Receipts MC-OCR 2021  
**Nguồn Kaggle ghi trong source dự án:** https://www.kaggle.com/datasets/domixi1989/vietnamese-receipts-mc-ocr-2021/data

Notebook train tìm file `mcocr_train_df.csv` trong `/kaggle/input`, xác định thư mục ảnh `train_images` rồi tạo crop text-line từ polygon annotations. Bản dữ liệu huấn luyện được gắn làm Kaggle Input, không chép toàn bộ ảnh vào ZIP source dưới 10 MB.

Ngoài MC-OCR, notebook tạo dữ liệu bổ sung các dòng chứa số điện thoại theo quy tắc sinh dữ liệu trong chính Cell 10, dùng ở Stage B. Đây là augmentation do code sinh ra, không phải nguồn dataset public độc lập.
