# THÔNG TIN PHIÊN BẢN MODEL STABLE (Native Speed V3)

Model deployment sử dụng **PP-OCRv6 Detector V6 + PP-OCRv6 Recognizer V6 TopK-F32**. Hai tệp `.onnx` là trọng số nhị phân; source code và notebook huấn luyện nằm trong ZIP mục 7. Do giới hạn source 10 MB, gói nộp chỉ kèm bản từ điển và thông tin định danh model.

| File cần cho Android | Kích thước | SHA-256 |
|---|---:|---|
| `model1_detector.onnx` | 9,891,707 bytes | `3914f972d833af87d23bb2338bd09238f978a48f3c4dbb8e1a4ee26a93869940` |
| `model2_recognizer.onnx` | 21,148,743 bytes | `550aae3077d7850d7217e2a6137c9a837fcb1364ab0fc9cc97f4982ac43da638` |
| `ppocr_keys.txt` | 74,947 bytes | `b5f2bfe2bdd9448429e3e82b51c789775d9b42f2403d082b00662eb77e401c5d` |

**Đường dẫn asset khi build:** `android/app/src/main/assets/smartlocker/`.

Nguồn đối chiếu SHA-256: file trọng số stable có trong bộ project gốc do nhóm cung cấp. Gói source không trộn model thử nghiệm/prune/int8 vào bản triển khai chính.

## Mã tái tạo format đầu ra

`01_TRAIN/export_recognizer_topk_f32.py` tạo format TopK-F32 từ raw `model2_recognizer.onnx` do Cell 13 sinh ra, kiểm tra đầu ra [N,T,2]. Định danh SHA256 trong bảng này là của **trọng số stable đang sử dụng**; không có cam kết trùng hash với kết quả của một lần train/export khác.
