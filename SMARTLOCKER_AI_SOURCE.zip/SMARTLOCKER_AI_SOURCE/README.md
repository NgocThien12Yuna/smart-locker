# SMARTLOCKER — MỤC 7: SOURCE CODE AI MODEL

**Đề tài:** SmartLocker — trích xuất số điện thoại người nhận từ ảnh nhãn giao hàng.  
**Bản ứng dụng được đối chiếu:** PP-OCRv6 / ONNX / Native Speed V3 / Receiver Selector V4.  
**Phạm vi:** mã nguồn AI, **không phải** toàn bộ project Android, backend hoặc firmware IoT.

## Bắt đầu từ đâu?

1. Mở `01_TRAIN/SmartLocker_PP-OCRv6_MC-OCR_FULL_14_CELLS_FIXED_V2.ipynb` (14 cell): xuất phát từ Detector pretrained, fine-tune Recognizer với bộ MC-OCR và dữ liệu số điện thoại tăng cường; export raw ONNX.
2. Mở `01_TRAIN/export_recognizer_topk_f32.py` và `QUY_TRINH_EXPORT_TOPK.md`: chuyển raw recognizer ONNX thành phiên bản **TopK-F32** với đúng hai output của ứng dụng; có kiểm tra parity khi chạy.
3. Mở `02_EVAL/SMARTLOCKER_TEST_FULL_8_CELLS_V4_HYBRID.ipynb` (8 cell) cùng `ground_truth_FIXED.csv`: đánh giá nhận đúng SĐT người nhận trên bộ robustness/unseen.
4. Mở `03_ANDROID_APP/android/app/src/main/java/com/smartlockerapp/ai/SmartLockerOcrNativeModule.kt`: Kotlin nạp ONNX, tiền xử lý/deskew, phát hiện box, OCR batch và CTC decode.
5. Mở `03_ANDROID_APP/src/ai/smartlockerOcr.ts`: Candidate Scoring V4, kiểm tra số điện thoại Việt Nam, phân biệt người gửi/người nhận và fallback góc xoay.

## Sơ đồ pipeline

```text
MC-OCR + phone augmentation
    -> Fine-tune PP-OCRv6 Recognizer (Detector pretrained)
    -> Paddle inference -> Paddle2ONNX raw
    -> TopK-F32 export + kiểm tra bằng ONNX Runtime

React Native Camera -> Android Native Kotlin
    -> decode/resize/auto-deskew
    -> Detector V6 -> crop vùng chữ
    -> Recognizer TopK-F32 -> text/box/confidence
    -> Receiver Selector V4 -> SĐT người nhận / trạng thái chưa chắc
```

## Bộ source gồm

| Thư mục | Nội dung |
|---|---|
| `01_TRAIN` | 14-cell training notebook, script export TopK-F32, hướng dẫn export |
| `02_EVAL` | 8-cell evaluation notebook, 36 hàng nhãn ground truth |
| `03_ANDROID_APP` | Các file AI/ứng dụng tích hợp Kotlin, TS/TSX và cấu hình phụ thuộc |
| `04_MODEL_DICTIONARY` | Bảng 18.708 ký tự dùng trong Recognizer (chưa kể blank và space) |
| `05_DATASET_AND_MODELS` | Link MC-OCR đã ghi trong source, tên và SHA256 weights stable |
| `06_HUONG_DAN` | Luồng AI, giải thích file, cách chạy train/export/eval/Android |
| `07_KIEM_TRA` | Công cụ tự kiểm tra tính toàn vẹn source và thông tin model |

## Dữ liệu và weights

- **Dataset gốc:** Vietnamese Receipts MC-OCR 2021, link trong `05_DATASET_AND_MODELS/DATASET_MC_OCR.md`.
- **Detector:** sử dụng pretrained PP-OCRv6 Small, không fine-tune trong notebook này.
- **Recognizer:** fine-tune Stage A trên MC-OCR; Stage B bổ sung dữ liệu số điện thoại sinh tổng hợp.
- **Weights ONNX:** lưu riêng khỏi ZIP mã nguồn do giới hạn kích thước 10 MB. Tên/kích thước/hash ghi trong `05_DATASET_AND_MODELS/PHIEN_BAN_MODEL.md`.

## Tự kiểm tra

```bash
python 07_KIEM_TRA/verify_source.py
```

Công cụ kiểm tra sự hiện diện của code, cú pháp script export, số cell train/eval, nhãn đánh giá và hash dictionary. Mã nguồn được trích từ bản stable; không trộn INT8, Progressive ROI hay Adaptive Width thử nghiệm.
